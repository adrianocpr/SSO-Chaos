var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

var arc_download_json = {
    file_name: "pgp_2.4.2.0613.exe",
    file_size: "61241680",
    update_date: "2016-06-13",
    filemd5: "cf5d4bfcda5b73e65b47aad95165de2b",
    url: "https://web.archive.org/web/20160613212804/http://client.pgp.wanmei.com/arcclient/client/pgp_2.4.2.0613.exe",
    end: "pgp_2.4.2.0613.exe"
}


}
/*
     FILE ARCHIVED ON 21:28:04 Jun 13, 2016 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 16:36:25 Jun 21, 2025.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 0.832
  exclusion.robots: 0.027
  exclusion.robots.policy: 0.012
  esindex: 0.019
  cdx.remote: 8.308
  LoadShardBlock: 68.738 (3)
  PetaboxLoader3.datanode: 57.914 (4)
  load_resource: 125.344
  PetaboxLoader3.resolve: 82.477
*/